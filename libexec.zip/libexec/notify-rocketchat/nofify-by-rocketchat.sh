#!/bin/bash
# This script is used by Gmetrics to post alerts into a Rocketchat channel
# using the Incoming WebHooks integration. Create the channel, botname
# and integration first and then add this notification script in your
# Gmetrics configuration.
#
# All variables that start with Gmetrics are provided by Gmetrics monitoring
# as environment variables when an notification is generated.
# A list of the env variables is available here:
# https://www.groots.in
#
# More info on Rocketchat
# Website: https://slack.com/
# Twitter: @slackhq, @slackapi
#
# Info
# Website: https://www.groots.in
# https://api.slack.com/apps/A0104GD978W/incoming-webhooks?success=1
#######################################################

#Set script name
#######################################################
SCRIPTNAME=`basename $0`

# Import Hostname
#######################################################
HOSTNAME=$(hostname)

# Logfile
#######################################################
LOGFILE=/var/log/groots/"$SCRIPTNAME".log
LOGDIR=/var/log/groots/
if [ ! -d $LOGDIR ]
then
        mkdir -p $LOGDIR
elif [ ! -f $LOGFILE ]
then
        touch $LOGFILE
fi

# Logger function
#######################################################
log () {
while read line; do echo "[`date +"%Y-%m-%dT%H:%M:%S,%N" | rev | cut -c 7- | rev`][$SCRIPTNAME]: $line"| tee -a $LOGFILE 2>&1 ; done
}

# Usage details
#######################################################

if [ "${1}" = "--help" -o "${#}" != "4" ];
       then
       echo -e "USAGE : $SCRIPTNAME -m [Rocketchat Message] -w [Rocketchat Webhook URL]

        OPTION          DESCRIPTION
        ----------------------------------
        --help                  Help
        -m [Rocketchat Message]      Rocketchat input message.
        -w [Rocketchat Webhook URL]  Rocketchat incoming webhook url.
        ----------------------------------

        Usage: ./$SCRIPTNAME -m \"gmetrics alerts\" -w \"https://hooks.slack.com/services/T06KL13QT/B0107354Q2J/ClSmxPczV5y6Whxxxxxxx\"

";
       exit 3;
fi

#######################################################
# Get user-given variables
#######################################################

while getopts "m:w:" Input
do
        case ${Input} in
        m) GMETRICS_MESSAGE="$OPTARG" ;;
        w) WEBHOOK_URL="$OPTARG" ;;
        *) echo "USAGE : $SCRIPTNAME -m [Rocketchat Message] -w [Rocketchat Webhook URL]"
           exit 3
           ;;
        esac
done

#######################################################
# Main Logic
#######################################################

# Send notification alert to slack channel
#######################################################

echo "Gmetrics alert sending via Rocketchat at [`date`]." | log
echo "#######################################################" | log
echo -e "Alert posted on Rocketchat webhook $WEBHOOK_URL" | log
echo -e "$GMETRICS_MESSAGE" | log
STATE=`echo -e "$GMETRICS_MESSAGE" | egrep State | awk -F ":" '{print $2}' | sed 's/ //g'`

#Set the message icon based on Gmetrics service state
#######################################################
if [ "$STATE" = "CRITICAL" ] || [ "$STATE" = "DOWN" ]
then
ICON=":exclamation::exclamation::exclamation:"
elif [ "$STATE" = "WARNING" ]
then
ICON=":warning:"
elif [ "$STATE" = "OK" ] || [ "$STATE" = "UP" ]
then
ICON=":ok:"
elif [ "$STATE" = "UNKNOWN" ]
then
ICON=":question:"
else
ICON=":white_medium_square:"
fi

# Post alert to slack channel
#######################################################
#curl -Ss -X POST -H 'Content-type: application/json' --data "{ \"alias\": \"Gmetrics Notification\", \"text\": \"$GMETRICS_MESSAGE\" }" $WEBHOOK_URL | python -m json.tool| log

curl -Ss -X POST -H 'Content-type: application/json' --data "{ \"alias\": \"Gmetrics Notification\", \"text\": \"$GMETRICS_MESSAGE\", \"attachments\": [{ \"title\": \"Click Here Gmetrics Link\", \"title_link\": \"https://app.gmetrics.io/gmetrics/#cgi-bin/status.cgi?\" }]}" $WEBHOOK_URL | python -m json.tool| log

#curl -Ss -X POST -H 'Content-type: application/json' --data "{ \"alias\": \"Gmetrics Notification\", \"text\": \"Notification ALert\", \"attachments\": [{ \"mrkdwn_in\": [\"text\"], \"color\": "#764FA5", \"title\": \"Gmetrics Alert\", \"title_link\": \"http://192.168.1.72\", \"text\": \" $GMETRICS_MESSAGE\" }]}" $WEBHOOK_URL | python -m json.tool| log

echo "#######################################################" | log
# End Main Logic.
#######################################################
