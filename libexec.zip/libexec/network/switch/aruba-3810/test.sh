#!/bin/bash
#######################################################
# Program: To check network metrics (switch/router)
#
# Purpose:
#  To check switch network metrics
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

# Main function
#######################################################

# Set script name
#######################################################
SCRIPTNAME=$(basename $0)

# Usage details
#######################################################

if [ "${1}" = "--help" -o "${#}" != "10" ];
then
echo -e "
        OPTION                       DESCRIPTION
        --------------------------------------------------
        --help                       Help
        -x [Community name]         public|private|home
        -h [Switch IP]              Hostname|Ip for switch
        -m [metrics]                Metrics name
        -w [Warn]                   Warning threshold
        -c [Crit]                   Critical threshold
        --------------------------------------------------
        Ex: sh $SCRIPTNAME -x community -h switchIP -m [metricname] -w [warn] -c [crit] "
        exit 3;
fi

# Get user-given variables
#######################################################

while getopts "x:h:m:w:c:" options
do
    case $options in
        x) community=$OPTARG ;;
        h) switchHost=$OPTARG ;;
        m) metric=$OPTARG ;; 
        w) warn=$OPTARG ;;
        c) crit=$OPTARG ;;
        *) echo "Usage: $SCRIPTNAME  -x community -h switchIP -m metricName -w warn -c crit or Use Help --help"
            exit 3 ;;
    esac
done


if [ "$metric" == "load" ]; then
    LOAD=`snmpwalk -v 2c -O vqet -c "$community" $switchHost 1.3.6.1.4.1.25461.2.1.2.3.1`
    OUTPUT="load average: $LOAD |Cpuload=${LOAD}"%";$warn;$crit;"

    if [ "$LOAD" -le "$warn" ]
        then
            STATUS="OK";
            EXITSTAT=0;

        elif [ "$LOAD" -gt "$warn" ]
            then
            if [ "$LOAD" -gt "$crit" ]
            then
            STATUS="CRITICAL";
            EXITSTAT=2;
        else
            STATUS="WARNING";
            EXITSTAT=1;
        fi
    else
        STATUS="UNKNOWN";
        EXITSTAT=3;
    fi

    if [ "$STATUS" = "UNKNOWN" ]
    then
        echo "$STATUS - No data Found."
    else
        echo "$STATUS - $OUTPUT"
    fi

    exit $EXITSTAT
###############


elif [ "$metric" == "state" ]; then
    STATE=$(snmpwalk -v 2c -O vqe -c $community $switchHost  1.3.6.1.4.1.25461.2.1.2.1.11 | sed 's/\"//g')
        
    if [ "$STATE" = "active" ]
    then
        echo "OK HAState=$STATE | HAState=0;2;3"
    exit 0
    else
        echo "Warning HAState=$STATE | HAState=2;2;3"
    exit 1
    fi
################


# Uptime Status----------------------------------------------------------------------------------------------------------------------------------------
elif [ "$metric" == "uptime" ]; then
        UPTIME=$(snmpwalk -v 2c -O vqet -c $community $switchHost 1.3.6.1.2.1.1.3.0)
        strOutput=$UPTIME
        seconds=$((UPTIME/100%60))
        minutes=$((UPTIME/100/60%60))
        hours=$((UPTIME/100/60/60%24))
        days=$((UPTIME/100/60/60/24))
        strOutput="OK - $days days, $hours hours, $minutes minutes, $seconds seconds | Days=${days};;;;"
        echo $strOutput
        exit 0


# Session Status---------------------------------------------------------------------------------------------------------------------------------------
elif [ "$metric" == "sessionuse" ]; then
    SESSIONTOTAL=$(snmpwalk -v 2c -O vqe -c $community $switchHost  1.3.6.1.4.1.25461.2.1.2.3.2)
        SESSIONUSE=$(snmpwalk -v 2c -O vqe -c $community $switchHost 1.3.6.1.4.1.25461.2.1.2.3.3)
        SESSIONTCP=$(snmpwalk -v 2c -O vqe -c $community $switchHost 1.3.6.1.4.1.25461.2.1.2.3.4)
        SESSIONUDP=$(snmpwalk -v 2c -O vqe -c $community $switchHost 1.3.6.1.4.1.25461.2.1.2.3.5)
        SESSIONICMP=$(snmpwalk -v 2c -O vqe -c $community $switchHost 1.3.6.1.4.1.25461.2.1.2.3.6)
        
        SESSIONSTAT=$(echo "$SESSIONUSE/$SESSIONTOTAL*100" | bc -l | awk '{printf "%.0f\n", $1}' )
        strOutput="$SESSIONSTAT% free|'SESSIONS'=$SESSIONSTAT%;$strWarning;$strCritical;;'Active'=$SESSIONUSE;0;$SESSIONTOTAL;;'TCP'=$SESSIONTCP;0;$SESSIONTOTAL;;'UDP'=$SESSIONUDP;0;$SESSIONTOTAL;;'ICMP'=$SESSIONICMP;0;$SESSIONTOTAL"
        
        if [ $SESSIONSTAT -ge "$crit" ]; then
           echo "CRITICAL: "$strOutput
        exit 2
        fi
        if [ $SESSIONSTAT -ge "$warn" ]; then
        echo "WARNING: "$strOutput
        exit 1
        fi
        echo "OK: "$strOutput
        exit 0

#
elif [ "$metric" == "temp" ]; then
        declare -a tempnames=($(snmpwalk -v 2c -O vqe -c $community $switchHost 1.3.6.1.2.1.47.1.1.1.1.7 | grep -n "Temperature" | awk -F : '{print $2}' | sed 's/\"//g' | sed 's/\Temperature at //g' | sed 's/\ //g' | tr '\n' ' '))
        declare -a temps=($(snmpwalk -v 2c -O vqe -c $community $switchHost 1.3.6.1.2.1.99.1.1.1.4 | sed '1,2d' | tr '\n' ' '))
                    c=0
                for line in ${tempnames[@]}
                do
                if [[ ${temps[${c}]} -gt 0 ]]
                then
                perfdata=$perfdata" ${tempnames[$c]}=${temps[${c}]};$warn;$crit"
                if [ ${temps[${c}]} -ge $crit ]
                    then
                        status="CRIT"
                        tempcrit=$fancrit"${tempnames[$c]}=${temps[${c}]}"
                elif [ ${temps[${c}]} -ge $warn ]
                        then
                        status="WARN"
                        tempwarn=$tempwarn"${tempnames[$c]}=${temps[${c}]}"
                else
                        status="OK"
                fi
                fi
                let c++
                done
        if [ "$status" == "CRIT" ]
        then
        echo "Critical $tempcrit|$perfdata"
        exit 2
        elif [ "$status" == "WARN" ]
        then
        echo "Warning $tempwarn|$perfdata"
        exit 1
        elif [ "$status" == "OK" ]
        then
        echo "Ok|$perfdata"
        exit 0
        else
        echo "unknown"
        exit 3
        fi

# Fan Status----------------------------------------------------------------------------------------------------------------------------------------
elif [ "$metric" == "fan" ]; then
        declare -a fannames=($(snmpwalk -v 2c -O vqe -c $community $switchHost 1.3.6.1.2.1.47.1.1.1.1.7 | grep -n "Fan" | awk -F : '{print $2}' | sed 's/\ //g'| sed 's/\"//g' | sed 's/\#//g' | sed 's/\Operational//g' | tr '\n' ' '))
        declare -a fans=($(snmpwalk -v 2c -O vqe -c $community $switchHost 1.3.6.1.2.1.99.1.1.1.4 | sed 2q | tr '\n' ' '))
                    c=0
                for line in ${fannames[@]}
                do
                echo ${fans[${c}]}
                if [ "${fans[${c}]}" -lt "1" ]
                    then
                                        status="CRIT"
                        fancrit=$fancrit"${fannames[$c]}=${fans[${c}]}"
                else
                        status="OK"
                fi
                let c++
                done
        if [ "$status" == "CRIT" ]
        then
        echo "Critical $fancrit"
        exit 2
        elif [ "$status" == "OK" ]
        then
        echo "ok"
        exit 0
        else
        echo "unknown"
        exit 3
        fi

fi

# End main

