package Thruk::Controller::watch;

use warnings;
use strict;

use Data::Dumper;
use Thruk::Action::AddDefaults ();
use Thruk::Utils::Auth ();
use Thruk::Utils::Status ();

=head1 NAME

Thruk::Controller::watch - Thruk Controller

=head1 DESCRIPTION

Thruk Controller.

=head1 METHODS

=cut

=head2 index

=cut


##########################################################
sub index {
    my( $c ) = @_;

    return unless Thruk::Action::AddDefaults::add_defaults($c, Thruk::Constants::ADD_DEFAULTS);

    my $type = $c->req->parameters->{'type'} || 0;

    if(!$c->config->{'extinfo_modules_loaded'}) {
        require Thruk::Utils::RecurringDowntimes;
        $c->config->{'extinfo_modules_loaded'} = 1;
    }

    $c->stash->{title}        = 'Watch List';
    $c->stash->{page}         = 'watch';
    $c->stash->{template}     = 'watch.tt';

    my $infoBoxTitle;
    $infoBoxTitle = 'Watch List';

    _process_service_page($c);


#### Host Health and Network Health 

    $c->stash->{'stats'}         = $c->db->get_performance_stats( services_filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'services' ) ], hosts_filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'hosts' ) ] );

    $c->stash->{'host_stats'}    = $c->db->get_host_stats(filter => [ Thruk::Utils::Auth::get_auth_filter($c, 'hosts')]);

    $c->stash->{'service_stats'} = $c->db->get_service_stats(filter => [ Thruk::Utils::Auth::get_auth_filter($c, 'services')]);


    $c->stash->{infoBoxTitle} = $infoBoxTitle;
    Thruk::Utils::ssi_include($c);

    Thruk::Action::AddDefaults::set_custom_title($c);

    return 1;
}

##########################################################
# SUBS
##########################################################

##########################################################
# create the service status

sub _process_service_page {
    my( $c ) = @_;

    my($hostfilter, $servicefilter) = Thruk::Utils::Status::do_filter($c);

    my $data = $c->db->get_services( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'services' ), $servicefilter ], extra_columns => [qw/long_plugin_output contacts/] );

    my @required_services = ( 'cpu_idle', 'cpu_load', 'ram_usage', 'cpu_utilization', 'server_info' );
    my $services = {};

    if( ref $data eq 'ARRAY' && scalar @{$data} ) {
        foreach my $record ( @{$data} ) {

            foreach my $service_name (@required_services) {
                $services->{$record->{host_name}}{$service_name} = {
                    'perf_data'        => $record->{perf_data},
                    'plugin_output'    => $record->{plugin_output},
                    'long_plugin_output'    => $record->{long_plugin_output},
                    'has_been_checked' => $record->{has_been_checked},
                    'state'            => $record->{state}
                } if $record->{description} eq $service_name;
            }

            if ( $record->{description} =~ m/^disk_/) {
                 $services->{$record->{host_name}}{$record->{description}} = {
                    'perf_data'        => $record->{perf_data},
                    'plugin_output'    => $record->{plugin_output},
                };
            }

        }
    }

    my $utilization = {};

    if ( ref $services eq 'HASH' && scalar keys %{$services} ) {
        foreach my $host ( keys %{$services} ) {

            if ($services->{$host}{cpu_utilization}{plugin_output} =~ m/(\d+(?:\.\d+)?)/) {
        	my $cpu = $1;
        	push @{$utilization->{CPU}}, { cpu => $cpu, host => $host };
	    }

            if ($services->{$host}{ram_usage}{plugin_output} =~ m/(\d+(?:\.\d+)?)%/) {
        	my $memory = $1;
        	push @{$utilization->{MEM}}, { memory => $memory, host => $host };
	    }
        }
    }
    my $sort = {};
    my $count = 0;

    if( exists $utilization->{CPU} && ref $utilization->{CPU} eq 'ARRAY' && scalar @{$utilization->{CPU}} ) {
        foreach ( sort{ $b->{cpu} <=> $a->{cpu} } @{$utilization->{CPU}} ) {
            $count++;
            push @{$sort->{CPU}}, $_ ;
            last if $count == 5 ;
        }
    }


    $count = 0;
    if( exists $utilization->{MEM} && ref $utilization->{MEM} eq 'ARRAY' && scalar @{$utilization->{MEM}} ) {
        foreach ( sort{ $b->{memory} cmp $a->{memory} } @{$utilization->{MEM}} ) {
            $count++;
            push @{$sort->{MEM}}, $_ ;
            last if $count == 5 ;
        }
    }

    $c->stash->{'utilization'} = $sort;
    $c->stash->{'services'}    = $services;

    return 1;
}

1;
