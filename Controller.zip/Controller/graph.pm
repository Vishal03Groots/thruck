package Thruk::Controller::graph;

use warnings;
use strict;

use Data::Dumper;
use Thruk::Action::AddDefaults ();
use Thruk::Utils::Auth ();
use Thruk::Utils::Status ();

=head1 NAME

Thruk::Controller::watch - Thruk Controller

=head1 DESCRIPTION

Thruk Controller.

=head1 METHODS

=cut

=head2 index

=cut


##########################################################
sub index {
    my( $c ) = @_;

    return unless Thruk::Action::AddDefaults::add_defaults($c, Thruk::Constants::ADD_DEFAULTS);

    my $url = $c->req->parameters->{'url'};
    my $target = $c->req->parameters->{'target'};

    $c->stash->{title}        = 'Graph';
    $c->stash->{page}         = 'graph';
    $c->stash->{template}     = 'graph.tt';

    Thruk::Utils::ssi_include($c);

    $c->stash->{'url'} = $url;
    $c->stash->{'target'} = $target;
    
    my %query_param = $url =~ m/(\w+)=(\w+)/g;

    $c->stash->{'host'} = $query_param{host};
    $c->stash->{'service'} = $query_param{service};

    $url =~ s/&amp;/&/g;
    Thruk::Action::AddDefaults::set_custom_title($c);
    #return $c->redirect_to($url);
    return 1;
}


1;
