package Thruk::Controller::favourite;

use warnings;
use strict;
use Cpanel::JSON::XS qw/decode_json/;

use Thruk::Action::AddDefaults ();
use Thruk::Backend::Manager ();
use Thruk::Utils::Auth ();
use Thruk::Utils::Status ();

=head1 NAME

Thruk::Controller::status - Thruk Controller

=head1 DESCRIPTION

Thruk Controller.

=head1 METHODS

=head2 index

=cut

##########################################################
sub index {
    my($c) = @_;

    return unless Thruk::Action::AddDefaults::add_defaults($c, Thruk::Constants::ADD_CACHED_DEFAULTS);

    my $data = Thruk::Utils::get_user_data($c);

    unless( $data->{favourite} ){
        $c->stash->{template} = 'status_favourite.tt';
        return 1;
    }

    # set some defaults
    Thruk::Utils::Status::set_default_stash($c);

    $c->stash->{title}         = 'Favourite Items';
    $c->stash->{infoBoxTitle}  = 'Favourite Items';
    $c->stash->{page}          = 'status';
    $c->stash->{show_top_pane} = 1;
    $c->stash->{style}         = $c->req->parameters->{'style'};
    $c->stash->{'num_hosts'}   = 0;
    $c->stash->{'custom_vars'} = [];

    # raw data request?
    $c->stash->{'output_format'} = $c->req->parameters->{'format'} || 'html';
    if($c->stash->{'output_format'} ne 'html') {
        return unless _process_raw_request($c);
        return 1;
    }

    if ( $c->req->parameters->{fav_services} ){

        $c->stash->{fav_services} = 1;
        $c->stash->{substyle} = 'service';

        if ( ref($data->{favourite}{service}) eq 'ARRAY' && scalar @{$data->{favourite}{service}} ){
            my $count = 0;
            foreach my $service_data (@{$data->{favourite}{service}}) {
                my($host, $service) = split /\|/mx, $service_data;
                $c->req->parameters->{'dfl_s' . $count . '_type'}  = ['host', 'service'];
                $c->req->parameters->{'dfl_s' . $count . '_op'}    = ['=', '='] ;
                $c->req->parameters->{'dfl_s' . $count . '_value'} = [$host, $service];

                $count++;
            }
            return unless _process_details_page($c);

        } else {
            $c->stash->{template} = 'status_favourite.tt';
            return 1;
        }
    } else {

        if ( ref($data->{favourite}{host}) eq 'ARRAY' && scalar @{$data->{favourite}{host}} ){

            $c->req->parameters->{'style'} = 'hostdetail';
            $c->stash->{substyle} = 'host';

            my $count = 0;
            foreach my $host (@{$data->{favourite}{host}}) {
                $c->req->parameters->{'dfl_s' . $count . '_type'}  = 'host';
                $c->req->parameters->{'dfl_s' . $count . '_op'}    = '=';
                $c->req->parameters->{'dfl_s' . $count . '_value'} = $host;

                $count++;
            }
            return unless _process_hostdetails_page($c);

        } else {
            $c->stash->{template} = 'status_favourite.tt';
            return 1;
        }
    }

    $c->stash->{template} = 'status_favourite.tt';

    Thruk::Utils::ssi_include($c);

    return 1;
}

##########################################################
# check for search results
sub _process_raw_request {
    my($c) = @_;

    my $limit = $c->req->parameters->{'limit'};
    my $type  = $c->req->parameters->{'type'}  || 'all';
    if($c->req->parameters->{'page'}) {
        $limit = $c->req->parameters->{'page'} * $limit;
    }

    my $filter;
    if($c->req->parameters->{'query'}) {
        $filter = $c->req->parameters->{'query'};
        $filter =~ s/\s+/\.\*/gmx;
        if($filter =~ s/^(\w{2}:)//mx) {
            my $prefix = $1;
            if($prefix eq 'ho:') { $type = "host"; }
            if($prefix eq 'se:') { $type = "service"; }
            if($prefix eq 'hg:') { $type = "hostgroup"; }
            if($prefix eq 'sg:') { $type = "servicegroup"; }
        }
        if($filter eq '*') { $filter = ""; }
    }

    my $json;
    if($type eq 'contact' || $type eq 'contacts') {
        my $data = [];
        my $size = 0;
        if(!$c->check_user_roles("authorized_for_configuration_information")) {
            $data = ["you are not authorized for configuration information"];
        } else {
            ($data, $size) = $c->db->get_contacts( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'contact' ), name => { '~~' => $filter } ], columns => [qw/name alias/], limit => $limit );
        }
        if($c->req->parameters->{'wildcards'}) {
            unshift @{$data}, { name => '*', alias => '*' };
            $size++;
        }
        push @{$json}, { 'name' => "contacts", 'data' => $data, 'total' => $size };
    }

    if($type eq 'host' || $type eq 'hosts' || $type eq 'all') {
        my($data, $size) = $c->db->get_hosts( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'hosts' ), name => { '~~' => $filter } ], columns => [qw/name alias/], limit => $limit );
        push @{$json}, { 'name' => "hosts", 'data' => $data, 'total' => $size };
    }

    if($type eq 'hostgroup' || $type eq 'hostgroups' || $type eq 'all') {
        my $data = [];
        my $hostgroups = $c->db->get_hostgroup_names_from_hosts(filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'hosts' )]);
        my $alias      = $c->db->get_hostgroups( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'hostgroups' )], columns => [qw/name alias/]);
        $alias = Thruk::Base::array2hash($alias, "name");
        for my $group (@{$hostgroups}) {
            my $row = $alias->{$group};
            next unless(!$filter || ($row->{'name'}.' - '.$row->{'alias'}) =~ m/$filter/mxi);
            push @{$data}, $row;
        }
        push @{$json}, { 'name' => "hostgroups", 'data' => $data };
    }

    if($type eq 'servicegroup' || $type eq 'servicegroups' || $type eq 'all') {
        my $data = [];
        my $servicegroups = $c->db->get_servicegroup_names_from_services(filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'services' )]);
        my $alias         = $c->db->get_servicegroups( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'servicegroups' ) ], columns => [qw/name alias/] );
        $alias = Thruk::Base::array2hash($alias, "name");
        for my $group (@{$servicegroups}) {
            my $row = $alias->{$group};
            next unless(!$filter || ($row->{'name'}.' - '.$row->{'alias'}) =~ m/$filter/mxi);
            push @{$data}, $row;
        }
        push @{$json}, { 'name' => "servicegroups", 'data' => $data };
    }

    if($type eq 'service' || $type eq 'services' || $type eq 'all') {
        my $host = $c->req->parameters->{'host'};
        my $additional_filter;
        my @hostfilter;
        if(defined $host and $host ne '') {
            for my $h (split(/\s*,\s*/mx, $host)) {
                next if $h eq '*';
                my $op = "=";
                if(Thruk::Base::looks_like_regex($h)) {
                    $op = "~";
                }
                push @hostfilter, { 'host_name' => { $op => $h }};
            }
            $additional_filter = Thruk::Utils::combine_filter('-or', \@hostfilter);
        }
        my($data, $size) = $c->db->get_service_names( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'services' ), $additional_filter, description => { '~~' => $filter } ], limit => $limit );
        push @{$json}, { 'name' => "services", 'data' => $data, 'total' => $size };
    }

    if($type eq 'timeperiod' or $type eq 'timeperiods') {
        my($data, $size) = $c->db->get_timeperiod_names( filter => [ name => { '~~' => $filter } ], limit => $limit );
        push @{$json}, { 'name' => "timeperiods", 'data' => $data, 'total' => $size };
    }

    if($type eq 'command' or $type eq 'commands') {
        my $data = [];
        if(!$c->check_user_roles("authorized_for_configuration_information")) {
            $data = ["you are not authorized for configuration information"];
        } else {
            my $commands = $c->db->get_commands( filter => [ name => { '~~' => $filter } ], columns => ['name'] );
            $data = [];
            for my $d (@{$commands}) {
                push @{$data}, $d->{'name'};
            }
        }
        push @{$json}, { 'name' => "commands", 'data' => $data };
    }

    if($type eq 'custom variable' || $type eq 'custom value') {
        # get available custom variables
        my $data = [];
        my $exposed_only = $c->req->parameters->{'exposed_only'} || 0;
        if($type eq 'custom variable' || !$c->check_user_roles("authorized_for_configuration_information")) {
            $data = Thruk::Utils::Status::get_custom_variable_names($c, 'all', $exposed_only, $filter);
        }
        if($type eq 'custom value') {
            my $allowed = $data;
            my $varname = $c->req->parameters->{'var'} || '';
            if(!$c->check_user_roles("authorized_for_configuration_information") && !grep/^\Q$varname\E$/mx, @{$allowed}) {
                $data = ["you are not authorized for this custom variable"];
            } else {
                my $uniq = {};
                my $hosts    = $c->db->get_hosts(    filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'hosts' ),    { 'custom_variable_names' => { '>=' => $varname } }], columns => ['custom_variable_names', 'custom_variable_values'] );
                my $services = $c->db->get_services( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'services' ), { 'custom_variable_names' => { '>=' => $varname } }], columns => ['custom_variable_names', 'custom_variable_values'] );
                for my $obj (@{$hosts}, @{$services}) {
                    my %vars;
                    @vars{@{$obj->{custom_variable_names}}} = @{$obj->{custom_variable_values}};
                    $uniq->{$vars{$varname}} = 1;
                }
                if($varname eq 'THRUK_ACTION_MENU' && $c->config->{'action_menu_items'}) {
                    # add available action menus
                    for my $key (keys %{$c->config->{'action_menu_items'}}) {
                        $uniq->{$key} = 1;
                    }
                }
                @{$data} = sort keys %{$uniq};
                @{$data} = grep(/$filter/mxi, @{$data}) if $filter;
            }
        }
        push @{$json}, { 'name' => $type."s", 'data' => $data };
    }

    if($type eq 'contactgroup' || $type eq 'contactgroups') {
        my $data = [];
        if($c->req->parameters->{'wildcards'}) {
            push @{$data}, '*';
        }
        my($groups, $size) = $c->db->get_contactgroups(filter => [ Thruk::Utils::Auth::get_auth_filter($c, 'contactgroups'), name => { '~~' => $filter } ], columns => [qw/name/], sort => {ASC=> 'name'}, limit => $limit);
        for my $g (@{$groups}) {
            push @{$data}, $g->{'name'};
        }
        push @{$json}, { 'name' => "contactgroups", 'data' => $data, 'total' => $size };
    }

    if($type eq 'event handler') {
        my $data = [];
        if(!$c->check_user_roles("authorized_for_configuration_information")) {
            $data = ["you are not authorized for configuration information"];
        } else {
            $data = $c->db->get_services( filter => [ -or => [ { host_event_handler => { '~~' => $filter }},
                                                                    {      event_handler => { '~~' => $filter }},
                                                                    ]],
                                                columns => [qw/host_event_handler event_handler/],
                                            );
            my $eventhandler = {};
            for my $d (@{$data}) {
                $eventhandler->{$d->{host_event_handler}} = 1 if $d->{host_event_handler};
                $eventhandler->{$d->{event_handler}}      = 1 if $d->{event_handler};
            }
            $data = [sort keys %{$eventhandler}];
        }
        push @{$json}, { 'name' => "event handlers", 'data' => $data };
    }

    if($type eq 'site') {
        my $data = [];
        for my $key (@{$c->stash->{'backends'}}) {
            my $b = $c->stash->{'backend_detail'}->{$key};
            push @{$data}, $b->{'name'};
        }
        @{$data} = sort @{$data};
        @{$data} = grep(/$filter/mxi, @{$data}) if $filter;
        push @{$json}, { 'name' => "sites", 'data' => $data };
    }

    if($type eq 'navsection') {
        Thruk::Utils::Menu::read_navigation($c);
        my $data = [];
        for my $section (@{$c->stash->{'navigation'}}) {
            push @{$data}, $section->{'name'};
        }
        @{$data} = sort @{$data};
        @{$data} = grep(/$filter/mxi, @{$data}) if $filter;
        push @{$json}, { 'name' => "navsections", 'data' => $data };
    }

    # make lists uniq
    for my $res (@{$json}) {
        $res->{'total_none_uniq'} = scalar @{$res->{'data'}};
        $res->{'data'} = Thruk::Backend::Manager::remove_duplicates($res->{'data'});
    }

    if($c->req->parameters->{'hash'}) {
        my $data  = $json->[0]->{'data'};
        my $total = $json->[0]->{'total'} || scalar @{$data};
        Thruk::Utils::page_data($c, $data, $c->req->parameters->{'limit'}, $total);
        my $list = [];
        if(scalar @{$c->stash->{'data'}} > 0 && ref $c->stash->{'data'}->[0] eq 'HASH') {
            for my $d (@{$c->stash->{'data'}}) {
                if($d->{'name'} ne $d->{'alias'}) {
                    push @{$list}, { 'text' => $d->{'name'}.' - '.$d->{'alias'}, value => $d->{'name'} };
                } else {
                    push @{$list}, { 'text' => $d->{'name'}, value => $d->{'name'} };
                }
            }
        } else {
            for my $d (@{$c->stash->{'data'}}) { push @{$list}, { 'text' => $d, 'value' => $d } }
        }
        $json = { 'data' => $list, 'total' => $total };
    }

    return $c->render(json => $json);
}


##########################################################
# create the status details page
sub _process_details_page {
    my( $c ) = @_;

    my $view_mode = $c->req->parameters->{'view_mode'} || 'html';
    $c->stash->{'minimal'} = 1 if $view_mode ne 'html';
    $c->stash->{'show_column_select'} = 1;
    $c->stash->{'hide_filter'}        = 0;

    my $has_columns = 0;
    my $user_data = Thruk::Utils::get_user_data($c);
    $c->stash->{'default_columns'}->{'dfl_'} = Thruk::Utils::Status::get_service_columns($c);
    my $selected_columns = $c->req->parameters->{'dfl_columns'} || $user_data->{'columns'}->{'svc'} || $c->config->{'default_service_columns'};
    $c->stash->{'table_columns'}->{'dfl_'}   = Thruk::Utils::Status::sort_table_columns($c->stash->{'default_columns'}->{'dfl_'}, $selected_columns);
    $c->stash->{'comments_by_host'}          = {};
    $c->stash->{'comments_by_host_service'}  = {};
    if($selected_columns) {
        Thruk::Utils::Status::set_comments_and_downtimes($c) if($selected_columns =~ m/comments/mx || $c->req->parameters->{'autoShow'});
        $has_columns = 1;
    }
    $c->stash->{'has_columns'} = $has_columns;
    $c->stash->{'has_user_columns'}->{'dfl_'} = $user_data->{'columns'}->{'svc'} ? 1 : 0;

    # which host to display?
    my($hostfilter, $servicefilter) = Thruk::Utils::Status::do_filter($c);
    return 1 if $c->stash->{'has_error'};

    if($c->req->parameters->{'q'}) {
        $c->stash->{'has_service_filter'}= 1;
        $c->stash->{'hide_filter'}= 1;
        $servicefilter = Thruk::Utils::Status::parse_lexical_filter($c->req->parameters->{'q'});
    }

    # do the sort
    my $sorttype   = $c->req->parameters->{'sorttype'}   || 1;
    my $sortoption = $c->req->parameters->{'sortoption'} || 1;
    my $order      = "ASC";
    $order = "DESC" if $sorttype eq "2";
    my $sortoptions = {
        '1' => [ [ 'host_name',   'description' ], 'host name' ],
        '2' => [ [ 'description', 'host_name' ],   'service name' ],
        '3' => [ [ 'has_been_checked', 'state_order', 'host_name', 'description' ], 'service status' ],
        '4' => [ [ 'last_check',              'host_name', 'description' ], 'last check time' ],
        '5' => [ [ 'current_attempt',         'host_name', 'description' ], 'attempt number' ],
        '6' => [ [ 'last_state_change_order', 'host_name', 'description' ], 'state duration' ],
        '7' => [ [ 'peer_name', 'host_name', 'description' ], 'site' ],
        '9' => [ [ 'plugin_output', 'host_name', 'description' ], 'status information' ],
    };
    for(my $x = 0; $x < scalar @{$c->stash->{'default_columns'}->{'dfl_'}}; $x++) {
        if(!defined $sortoptions->{$x+10}) {
            my $col = $c->stash->{'default_columns'}->{'dfl_'}->[$x];
            my $field = $col->{'field'};
            if($field =~ m/^cust_(.*)$/mx) { $field = "custom_variables ".uc($1); }
            $sortoptions->{$x+10} = [[$field], lc($col->{"title"}) ];
        }
    }
    $sortoption = 1 if !defined $sortoptions->{$sortoption};

    # reverse order for duration
    my $backend_order = $order;
    if($sortoption eq "6") { $backend_order = $order eq 'ASC' ? 'DESC' : 'ASC'; }

    my($columns, $keep_peer_addr, $keep_peer_name, $keep_peer_key, $keep_last_state, $keep_state_order);
    if($view_mode eq 'json' and $c->req->parameters->{'columns'}) {
        @{$columns} = split(/\s*,\s*/mx, $c->req->parameters->{'columns'});
        my $col_hash = Thruk::Base::array2hash($columns);
        $keep_peer_addr   = delete $col_hash->{'peer_addr'};
        $keep_peer_name   = delete $col_hash->{'peer_name'};
        $keep_peer_key    = delete $col_hash->{'peer_key'};
        $keep_last_state  = delete $col_hash->{'last_state_change_order'};
        $keep_state_order = delete $col_hash->{'state_order'};
        @{$columns} = keys %{$col_hash};
    }

    my $extra_columns = [];
    if($c->config->{'use_lmd_core'} && $c->stash->{'show_long_plugin_output'} ne 'inline' && $view_mode eq 'html') {
        push @{$extra_columns}, 'has_long_plugin_output';
    } else {
        push @{$extra_columns}, 'long_plugin_output';
    }
    push @{$extra_columns}, 'contacts' if $has_columns;

    # get all services
    my $services = $c->db->get_services( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'services' ), $servicefilter ], sort => { $backend_order => $sortoptions->{$sortoption}->[0] }, pager => 1, columns => $columns, extra_columns => $extra_columns  );

    if(scalar @{$services} == 0 && !$c->stash->{'has_service_filter'}) {
        # try to find matching hosts, maybe we got some hosts without service
        my $host_stats = $c->db->get_host_stats( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'hosts' ), $hostfilter ] );
        $c->stash->{'num_hosts'} = $host_stats->{'total'};

        # redirect to host details page if there are hosts but no service filter
        if($c->stash->{'num_hosts'} > 0) {
            # remove columns, they are different for hosts
            my $url = $c->stash->{'url_prefix'}.'cgi-bin/'.Thruk::Utils::Filter::uri_with($c, {'style' => 'hostdetail', 'dfl_columns' => undef });
            $url =~ s/&amp;/&/gmx;
            Thruk::Utils::set_message( $c, 'info_message', 'No services found for this filter, redirecting to host view.' );
            return $c->redirect_to($url);
        }
    }

    if( $view_mode eq 'xls' ) {
        Thruk::Utils::Status::set_selected_columns($c, [''], 'service');
        $c->res->headers->header( 'Content-Disposition', 'attachment; filename="status.xls"' );
        $c->stash->{'data'}     = $services;
        $c->stash->{'template'} = 'excel/status_detail.tt';
        return $c->render_excel();
    }
    elsif ( $view_mode eq 'json' ) {
        # remove unwanted colums
        if($columns) {
            for my $s (@{$services}) {
                delete $s->{'peer_addr'}               unless $keep_peer_addr;
                delete $s->{'peer_name'}               unless $keep_peer_name;
                delete $s->{'peer_key'}                unless $keep_peer_key;
                delete $s->{'last_state_change_order'} unless $keep_last_state;
                delete $s->{'state_order'}             unless $keep_state_order;
            }
        }
        if(!$c->check_user_roles("authorized_for_configuration_information")) {
            # remove custom macro colums which could contain confidential informations
            for my $s (@{$services}) {
                delete $s->{'host_custom_variable_names'};
                delete $s->{'host_custom_variable_values'};
                delete $s->{'custom_variable_names'};
                delete $s->{'custom_variable_values'};
            }
        }
        return $c->render(json => $services);
    }

    $c->stash->{'orderby'}  = $sortoptions->{$sortoption}->[1];
    $c->stash->{'orderdir'} = $order;

    if($c->config->{'show_custom_vars'}
       and $c->stash->{'data'}
       and defined $c->stash->{'host_stats'}
       and ref($c->stash->{'host_stats'}) eq 'HASH'
       and defined $c->stash->{'host_stats'}->{'up'}
       and $c->stash->{'host_stats'}->{'up'} + $c->stash->{'host_stats'}->{'down'} + $c->stash->{'host_stats'}->{'unreachable'} + $c->stash->{'host_stats'}->{'pending'} == 1) {
        # set allowed custom vars into stash
        Thruk::Utils::set_custom_vars($c, {'prefix' => 'host_', 'host' => $c->stash->{'data'}->[0], 'add_host' => 1 });
    }

    return 1;
}

##########################################################
# create the hostdetails page
sub _process_hostdetails_page {
    my( $c ) = @_;

    my $view_mode = $c->req->parameters->{'view_mode'} || 'html';
    $c->stash->{'minimal'} = 1 if $view_mode ne 'html';
    $c->stash->{'show_column_select'} = 1;

    my $has_columns = 0;
    my $user_data = Thruk::Utils::get_user_data($c);
    my $selected_columns = $c->req->parameters->{'dfl_columns'} || $user_data->{'columns'}->{'hst'} || $c->config->{'default_host_columns'};
    $c->stash->{'show_host_attempts'} = defined $c->config->{'show_host_attempts'} ? $c->config->{'show_host_attempts'} : 0;
    $c->stash->{'default_columns'}->{'dfl_'} = Thruk::Utils::Status::get_host_columns($c);
    $c->stash->{'table_columns'}->{'dfl_'}   = Thruk::Utils::Status::sort_table_columns($c->stash->{'default_columns'}->{'dfl_'}, $selected_columns);
    $c->stash->{'comments_by_host'}          = {};
    $c->stash->{'comments_by_host_service'}  = {};
    if($selected_columns) {
        Thruk::Utils::Status::set_comments_and_downtimes($c) if($selected_columns =~ m/comments/mx || $c->req->parameters->{'autoShow'});
        $has_columns = 1;
    }
    $c->stash->{'has_columns'} = $has_columns;
    $c->stash->{'has_user_columns'}->{'dfl_'} = $user_data->{'columns'}->{'hst'} ? 1 : 0;

    # which host to display?
    my($hostfilter) = Thruk::Utils::Status::do_filter($c);
    return 1 if $c->stash->{'has_error'};

    # do the sort
    my $sorttype   = $c->req->parameters->{'sorttype'}   || 1;
    my $sortoption = $c->req->parameters->{'sortoption'} || 1;
    my $order      = "ASC";
    $order = "DESC" if $sorttype eq "2";
    my $sortoptions = {
        '1' => [ 'name', 'host name' ],
        '4' => [ [ 'last_check',              'name' ], 'last check time' ],
        '6' => [ [ 'last_state_change_order', 'name' ], 'state duration' ],
        '7' => [ [ 'peer_name', 'name' ], 'site' ],
        '8' => [ [ 'has_been_checked', 'state', 'name' ], 'host status' ],
        '9' => [ [ 'plugin_output', 'name' ], 'status information' ],
    };
    for(my $x = 0; $x < scalar @{$c->stash->{'default_columns'}->{'dfl_'}}; $x++) {
        if(!defined $sortoptions->{$x+10}) {
            my $col = $c->stash->{'default_columns'}->{'dfl_'}->[$x];
            my $field = $col->{'field'};
            if($field =~ m/^cust_(.*)$/mx) { $field = "custom_variables ".uc($1); }
            $sortoptions->{$x+10} = [[$field], lc($col->{"title"}) ];
        }
    }
    $sortoption = 1 if !defined $sortoptions->{$sortoption};

    # reverse order for duration
    my $backend_order = $order;
    if($sortoption eq "6") { $backend_order = $order eq 'ASC' ? 'DESC' : 'ASC'; }

    my($columns, $keep_peer_addr, $keep_peer_name, $keep_peer_key, $keep_last_state);
    if($view_mode eq 'json' and $c->req->parameters->{'columns'}) {
        @{$columns} = split(/\s*,\s*/mx, $c->req->parameters->{'columns'});
        my $col_hash = Thruk::Base::array2hash($columns);
        $keep_peer_addr  = delete $col_hash->{'peer_addr'};
        $keep_peer_name  = delete $col_hash->{'peer_name'};
        $keep_peer_key   = delete $col_hash->{'peer_key'};
        $keep_last_state = delete $col_hash->{'last_state_change_order'};
        @{$columns} = keys %{$col_hash};
    }

    my $extra_columns = [];
    if($c->config->{'use_lmd_core'} && $c->stash->{'show_long_plugin_output'} ne 'inline' && $view_mode eq 'html') {
        push @{$extra_columns}, 'has_long_plugin_output';
    } else {
        push @{$extra_columns}, 'long_plugin_output';
    }
    push @{$extra_columns}, 'contacts' if $has_columns;

    # get hosts
    my $hosts = $c->db->get_hosts( filter => [ Thruk::Utils::Auth::get_auth_filter( $c, 'hosts' ), $hostfilter ], sort => { $backend_order => $sortoptions->{$sortoption}->[0] }, pager => 1, columns => $columns, extra_columns => $extra_columns );

    if( $view_mode eq 'xls' ) {
        Thruk::Utils::Status::set_selected_columns($c, [''], 'host');
        my $filename = 'status.xls';
        $c->res->headers->header( 'Content-Disposition', qq[attachment; filename="] . $filename . q["]);
        $c->stash->{'data'}     = $hosts;
        $c->stash->{'template'} = 'excel/status_hostdetail.tt';
        return $c->render_excel();
    }
    if ( $view_mode eq 'json' ) {
        # remove unwanted colums
        if($columns) {
            for my $h (@{$hosts}) {
                delete $h->{'peer_addr'}               unless $keep_peer_addr;
                delete $h->{'peer_name'}               unless $keep_peer_name;
                delete $h->{'peer_key'}                unless $keep_peer_key;
                delete $h->{'last_state_change_order'} unless $keep_last_state;
            }
        }
        if(!$c->check_user_roles("authorized_for_configuration_information")) {
            # remove custom macro colums which could contain confidential informations
            for my $h (@{$hosts}) {
                delete $h->{'custom_variable_names'};
                delete $h->{'custom_variable_values'};
            }
        }
        return $c->render(json => $hosts);
    }

    $c->stash->{'orderby'}  = $sortoptions->{$sortoption}->[1];
    $c->stash->{'orderdir'} = $order;

    return 1;
}

1;
